import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class UserDataServiceService {
  constructor(public http: HttpClient) { }

  getUserData() {
    return this.http.get('https://randomuser.me/api/0.8/?results=20');
  }
}
