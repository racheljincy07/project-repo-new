import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class StorageServiceService {

  constructor() { }
    setValue(item: string, value: any) {
    localStorage.setItem(item, JSON.stringify(value));
  }
     removeValue(item: string) {
    localStorage.removeItem(item);
  }
  clearStorage() {
    localStorage.clear();
  }
}

