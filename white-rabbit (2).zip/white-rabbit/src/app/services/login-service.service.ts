import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { StorageServiceService } from './storage-service.service';

@Injectable({
  providedIn: 'root'
})

export class LoginServiceService {
   userCredential = [{
    "uername":"admin",
    "password": "password"
  },
    {
      "uername":"jincy.learing@gmail.com",
      "password": "attinad@123"
    }
  ];

  isLoggedIn;

  constructor(private router: Router,
    private storageService: StorageServiceService) { }
  login(username: string, password: string) {
    let loginDetails = {
      username : username,
      password: password
    }
     this.userCredential.forEach(el => {
       if(loginDetails.password == el.password && loginDetails.username == el.uername){
          this.isLoggedIn = true;
          this.router.navigate(['/home']);
          this.storageService.setValue('user details', loginDetails);
       }
       else{
        this.isLoggedIn = false;
       }
     })
  }
}



