import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home-page',
  templateUrl: './home-page.component.html',
  styleUrls: ['./home-page.component.scss']
})
export class HomePageComponent implements OnInit {
  loggedIn;
  constructor(              
    private route: ActivatedRoute
    ) { }

  userInfo : [];
  ngOnInit(): void {
    this.getUserInfo();
  }

  getUserInfo(){
  this.userInfo = this.route.snapshot.data.userDetailsResolver;
  }
}
