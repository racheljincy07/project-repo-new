import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserInformationComponent } from './shared-modules/user-information/user-information.component';
import { LoginComponent } from './login/login.component';
import { HomePageComponent } from './home-page/home-page.component';
import { userDetailsResolver } from './resolvers/user-detail.resolver';
import { NavBarComponent } from './shared-modules/nav-bar/nav-bar.component';


@NgModule({
  declarations: [
    AppComponent,
    UserInformationComponent,
    LoginComponent,
    HomePageComponent,
    NavBarComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule
  ],
  providers: [userDetailsResolver],
  bootstrap: [AppComponent]
})
export class AppModule { }
