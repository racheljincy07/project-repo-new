
import { Injectable } from '@angular/core';
import { Resolve, ActivatedRouteSnapshot, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { UserDataServiceService } from '../services/user-data-service.service';

@Injectable({
  providedIn: 'root'
})
export class userDetailsResolver implements Resolve<any> {
  constructor(
    private router: Router,
    private userService: UserDataServiceService
) { }

  resolve(route: ActivatedRouteSnapshot):  any {
    return this.userService.getUserData()
      .pipe(
        map(res => {
          return res;
        }),
        catchError((error,) => {
          return of({ error });
        })
      );
  }
}

