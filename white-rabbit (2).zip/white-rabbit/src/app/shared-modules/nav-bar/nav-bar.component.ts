import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginServiceService } from 'src/app/services/login-service.service';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.scss']
})
export class NavBarComponent implements OnInit {
  displayLogOut: boolean = false;
  constructor(private route: ActivatedRoute,
    private loginServiceService: LoginServiceService) { }

  ngOnInit(): void {
    this.displayLogOut = this.loginServiceService.isLoggedIn ? true: false;
  }

}
