import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { LoginServiceService } from '../services/login-service.service';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  username;
  password;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private loginServiceService: LoginServiceService) { }

  ngOnInit(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
  });
  }

  submit() {
    this.username =this.loginForm.value.username;
    this.password = this.loginForm.value.password;
    this.loginServiceService.login( this.username, this.password);
    }
}
